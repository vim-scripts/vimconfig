
// XXX XXX XXX  THIS IS A NEW FILE XXX XXX XXX

/*
 * @FILE_EXT@
 *
 * Developed by @AUTHOR@ <@EMAIL@>
 * Copyright (c) @YEAR@ @COMPANY@
 * Licensed under terms of GNU General Public License.
 * All rights reserved.
 *
 * Changelog:
 * @DATE@ - created
 *
 */

// $Platon$

package @JAVA_PACKAGE@;

/**
 * Short class description
 *
 * Long class description
 *
 * @author  <a href="mailto:@EMAIL@">@AUTHOR@</a>
 * @version 0.0.1
 */

public class @FILE@
{

	/**
	 * Main function
	 */
	public static void main(String[] args) // {{{
	{

	} // }}}

}

/* Modeline for ViM {{{
 * vim: set ts=4:
 * vim600: fdm=marker fdl=0 fdc=3:
 * }}} */

