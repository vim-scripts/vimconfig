
// XXX XXX XXX  THIS IS A NEW FILE XXX XXX XXX

/*
 * @FILE_EXT@
 *
 * Developed by @AUTHOR@ <@EMAIL@>
 * Copyright (c) @YEAR@ @COMPANY@
 * Licensed under terms of GNU General Public License.
 * All rights reserved.
 *
 * Changelog:
 * @DATE@ - created
 *
 */

/* $Platon$ */

#include <stdio.h>
#include "@FILE@.h"

int main(int argc, char **argv) /* {{{ */
{


	return 0;
} /* }}} */

/* Modeline for ViM {{{
 * vim: set ts=4:
 * vim600: fdm=marker fdl=0 fdc=3:
 * }}} */

