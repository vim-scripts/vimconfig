
# XXX XXX XXX  THIS IS A NEW FILE XXX XXX XXX

#!/usr/bin/perl

#
# @FILE_EXT@
#
# Developed by @AUTHOR@ <@EMAIL@>
# Copyright (c) @YEAR@ @COMPANY@
# Licensed under terms of GNU General Public License.
# All rights reserved.
#
# Changelog:
# @DATE@ - created
#

# $Platon$

use strict;

$| = 1;



# vim: ts=4
# vim600: fdm=marker fdl=0 fdc=3

