/*
 * $Log$
 * Revision 1.2  2002/02/06 01:13:40  host8
 * New commands:
 *     command! -nargs=0 LoadTemplateFile call LoadTemplateFile()
 *     command! -nargs=1 LoadFile call LoadFile(<args>)
 *
 *
 */
#ifndef @INCLUDE_GAURD@_H
#  define @INCLUDE_GAURD@_H


#endif /* ifndef @INCLUDE_GAURD@_H */
