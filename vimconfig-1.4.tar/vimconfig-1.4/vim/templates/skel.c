/*
 * $Log$
 * Revision 1.2  2002/02/06 01:13:40  host8
 * New commands:
 *     command! -nargs=0 LoadTemplateFile call LoadTemplateFile()
 *     command! -nargs=1 LoadFile call LoadFile(<args>)
 *
 *
 */

#include <stdio.h>
#include "@FILE@.h"

/* Function int main(int argc, char **argv) {{{ */
int main(int argc, char **argv)
{


	return 0;
} /* }}} */


/* Modeline for ViM {{{
 * vim:set ts=4:
 * vim600:fdm=marker fdl=0 fdc=3:
 * }}} */

